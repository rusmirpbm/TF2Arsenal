@echo off
call "%~dp0gradlew.bat" build
if errorlevel 1 exit /b %errorlevel%
echo.
echo ========================================
echo BUILD SUCCESSFUL
echo JAR: %~dp0build\libs\TF2Arsenal-0.2.0.jar
echo ========================================
