package com.tf2arsenal;

import com.tf2arsenal.block.ModBlocks;
import com.tf2arsenal.item.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(TF2Arsenal.MOD_ID)
public final class TF2Arsenal {
    public static final String MOD_ID = "tf2arsenal";

    public TF2Arsenal(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.BLOCK_ITEMS.register(modBus);
        ModBlocks.TABS.register(modBus);
    }
}
