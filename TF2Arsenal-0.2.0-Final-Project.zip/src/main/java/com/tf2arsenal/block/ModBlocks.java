package com.tf2arsenal.block;

import com.tf2arsenal.TF2Arsenal;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(TF2Arsenal.MOD_ID);
    public static final DeferredRegister.Items BLOCK_ITEMS = DeferredRegister.createItems(TF2Arsenal.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(net.minecraft.core.registries.Registries.CREATIVE_MODE_TAB, TF2Arsenal.MOD_ID);

    public static final DeferredHolder<Block, Block> AUSTRALIUM_ORE = BLOCKS.register("australium_ore", () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).destroyTime(3.5F).explosionResistance(6.0F).requiresCorrectToolForDrops()));
    public static final DeferredHolder<Block, Block> AMMO_CRATE = BLOCKS.register("ammo_crate", () -> new AmmoCrateBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).destroyTime(1.5F).explosionResistance(2.0F)));
    public static final DeferredHolder<Block, Block> SENTRY = BLOCKS.register("sentry", () -> new SentryBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).destroyTime(3.0F).explosionResistance(8.0F)));
    public static final DeferredHolder<Block, Block> DISPENSER = BLOCKS.register("dispenser", () -> new DispenserBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).destroyTime(2.5F).explosionResistance(8.0F)));
    public static final DeferredHolder<Block, Block> TELEPORTER = BLOCKS.register("teleporter", () -> new TeleporterBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).destroyTime(2.5F).explosionResistance(8.0F)));

    static {
        blockItem("australium_ore", AUSTRALIUM_ORE);
        blockItem("ammo_crate", AMMO_CRATE);
        blockItem("sentry", SENTRY);
        blockItem("dispenser", DISPENSER);
        blockItem("teleporter", TELEPORTER);
    }

    private static void blockItem(String id, DeferredHolder<Block, Block> block) {
        BLOCK_ITEMS.register(id, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("tf2arsenal", () -> CreativeModeTab.builder()
            .title(net.minecraft.network.chat.Component.translatable("itemGroup.tf2arsenal"))
            .icon(() -> new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.GOLD_INGOT))
            .displayItems((params, output) -> {
                output.accept(AUSTRALIUM_ORE.get());
                output.accept(AMMO_CRATE.get());
                output.accept(SENTRY.get());
                output.accept(DISPENSER.get());
                output.accept(TELEPORTER.get());
                output.accept(com.tf2arsenal.item.ModItems.AMMO.get());
                output.accept(com.tf2arsenal.item.ModItems.AUSTRALIUM_INGOT.get());
                output.accept(com.tf2arsenal.item.ModItems.MEDKIT.get());
                output.accept(com.tf2arsenal.item.ModItems.MEDIGUN.get());
                output.accept(com.tf2arsenal.item.ModItems.BUILD_PDA.get());
                com.tf2arsenal.item.ModItems.WEAPONS.values().forEach(h -> output.accept(h.get()));
            }).build());

    private ModBlocks() {}
}
