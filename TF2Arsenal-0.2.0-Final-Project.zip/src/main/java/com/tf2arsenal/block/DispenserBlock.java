package com.tf2arsenal.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.AABB;

public class DispenserBlock extends Block {
    public DispenserBlock(BlockBehaviour.Properties properties) { super(properties); }
    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, net.minecraft.util.RandomSource random) {
        for (Player p : level.getEntitiesOfClass(Player.class, new AABB(pos).inflate(5))) {
            p.heal(2.0F);
        }
        level.scheduleTick(pos, this, 20);
    }
    @Override
    protected void onPlace(net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.level.Level level, net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!level.isClientSide) level.scheduleTick(pos, this, 10);
    }

    @Override
    protected boolean isRandomlyTicking(BlockState state) { return false; }
}
