package com.tf2arsenal.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.AABB;

public class TeleporterBlock extends Block {
    public TeleporterBlock(BlockBehaviour.Properties properties) { super(properties); }
    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, net.minecraft.util.RandomSource random) {
        for (Player p : level.getEntitiesOfClass(Player.class, new AABB(pos).inflate(1.1))) {
            BlockPos target = findOther(level, pos);
            if (target != null) p.teleportTo(target.getX()+0.5, target.getY()+1.0, target.getZ()+0.5);
        }
        level.scheduleTick(pos, this, 10);
    }
    private BlockPos findOther(ServerLevel level, BlockPos origin) {
        for (int r=4;r<=48;r+=4) {
            for (BlockPos p : BlockPos.betweenClosed(origin.offset(-r,-8,-r), origin.offset(r,8,r))) {
                if (!p.equals(origin) && level.getBlockState(p).getBlock() == this) return p.immutable();
            }
        }
        return null;
    }
    @Override
    protected void onPlace(net.minecraft.world.level.block.state.BlockState state, net.minecraft.world.level.Level level, net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!level.isClientSide) level.scheduleTick(pos, this, 10);
    }

    @Override
    protected boolean isRandomlyTicking(BlockState state) { return false; }
}
