package com.tf2arsenal.item;

import com.tf2arsenal.TF2Arsenal;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.createItems(TF2Arsenal.MOD_ID);
    public static final Map<String, DeferredHolder<Item, Item>> WEAPONS = new LinkedHashMap<>();

    public static final DeferredHolder<Item, Item> AMMO = ITEMS.register("ammo", () -> new AmmoItem(new Item.Properties()));
    public static final DeferredHolder<Item, Item> AUSTRALIUM_INGOT = ITEMS.register("australium_ingot", () -> new Item(new Item.Properties()));
    public static final DeferredHolder<Item, Item> MEDKIT = ITEMS.register("medkit", () -> new MedkitItem(new Item.Properties()));
    public static final DeferredHolder<Item, Item> MEDIGUN = weapon("medigun", Tf2WeaponItem.Kind.HEAL, 6, 8, 10, false, false, 0);
    public static final DeferredHolder<Item, Item> BUILD_PDA = weapon("build_pda", Tf2WeaponItem.Kind.BUILD, 0, 1, 0, false, false, 0);

    private static DeferredHolder<Item, Item> weapon(String id, Tf2WeaponItem.Kind kind, float dmg, double range, int cd, boolean bleed, boolean crit, float blast) {
        DeferredHolder<Item, Item> holder = ITEMS.register(id, () -> new Tf2WeaponItem(new Item.Properties().stacksTo(1).durability(300), kind, dmg, range, cd, bleed, crit, blast));
        WEAPONS.put(id, holder);
        return holder;
    }

    static {
        // Scout
        weapon("scattergun", Tf2WeaponItem.Kind.GUN, 7.0F, 24, 8, false, false, 0);
        weapon("pistol", Tf2WeaponItem.Kind.GUN, 5.0F, 32, 4, false, false, 0);
        weapon("force_a_nature", Tf2WeaponItem.Kind.GUN, 9.0F, 22, 10, false, false, 0);
        weapon("shortstop", Tf2WeaponItem.Kind.GUN, 8.0F, 26, 8, false, false, 0);
        weapon("soda_popper", Tf2WeaponItem.Kind.GUN, 8.0F, 25, 7, false, false, 0);
        weapon("baby_faces_blaster", Tf2WeaponItem.Kind.GUN, 8.0F, 25, 7, false, false, 0);
        weapon("back_scatter", Tf2WeaponItem.Kind.GUN, 9.0F, 22, 8, false, false, 0);
        weapon("bonk_atomic_punch", Tf2WeaponItem.Kind.HEAL, 2.0F, 0, 0, false, false, 0);
        weapon("sandman", Tf2WeaponItem.Kind.MELEE, 7.0F, 4, 10, false, false, 0);
        weapon("wrap_assassin", Tf2WeaponItem.Kind.MELEE, 6.0F, 4, 10, true, false, 0);
        weapon("force_a_nature_melee", Tf2WeaponItem.Kind.MELEE, 8.0F, 4, 8, false, false, 0);
        weapon("atomizer", Tf2WeaponItem.Kind.MELEE, 7.0F, 4, 9, false, false, 0);
        weapon("fan_o_war", Tf2WeaponItem.Kind.MELEE, 3.0F, 4, 8, false, true, 0);
        // Soldier
        weapon("rocket_launcher", Tf2WeaponItem.Kind.EXPLOSIVE, 16.0F, 30, 12, false, false, 2.5F);
        weapon("direct_hit", Tf2WeaponItem.Kind.EXPLOSIVE, 24.0F, 35, 10, false, false, 1.5F);
        weapon("black_box", Tf2WeaponItem.Kind.EXPLOSIVE, 14.0F, 30, 14, false, false, 2.5F);
        weapon("liberty_launcher", Tf2WeaponItem.Kind.EXPLOSIVE, 12.0F, 30, 10, false, false, 2.0F);
        weapon("cow_mangler", Tf2WeaponItem.Kind.EXPLOSIVE, 13.0F, 30, 12, false, false, 2.0F);
        weapon("beggars_bazooka", Tf2WeaponItem.Kind.EXPLOSIVE, 13.0F, 28, 7, false, false, 2.3F);
        weapon("air_strike", Tf2WeaponItem.Kind.EXPLOSIVE, 12.0F, 30, 8, false, false, 2.0F);
        weapon("original", Tf2WeaponItem.Kind.EXPLOSIVE, 16.0F, 30, 12, false, false, 2.5F);
        weapon("shotgun", Tf2WeaponItem.Kind.GUN, 7.0F, 20, 8, false, false, 0);
        weapon("reserve_shooter", Tf2WeaponItem.Kind.GUN, 8.0F, 20, 6, false, false, 0);
        weapon("buff_banner", Tf2WeaponItem.Kind.HEAL, 3.0F, 6, 20, false, true, 0);
        weapon("concheror", Tf2WeaponItem.Kind.HEAL, 3.0F, 6, 20, false, true, 0);
        weapon("battalions_backup", Tf2WeaponItem.Kind.SHIELD, 2.0F, 6, 20, false, true, 0);
        weapon("disciplinary_action", Tf2WeaponItem.Kind.MELEE, 7.0F, 5, 9, false, false, 0);
        weapon("escape_plan", Tf2WeaponItem.Kind.MELEE, 6.0F, 4, 9, false, false, 0);
        weapon("equalizer", Tf2WeaponItem.Kind.MELEE, 9.0F, 4, 10, false, false, 0);
        weapon("market_gardener", Tf2WeaponItem.Kind.MELEE, 10.0F, 4, 10, false, true, 0);
        // Pyro
        weapon("flamethrower", Tf2WeaponItem.Kind.GUN, 5.0F, 12, 3, true, false, 0);
        weapon("backburner", Tf2WeaponItem.Kind.GUN, 7.0F, 12, 3, true, true, 0);
        weapon("degroot_axtinguisher", Tf2WeaponItem.Kind.MELEE, 11.0F, 4, 10, true, false, 0);
        weapon("phlogistinator", Tf2WeaponItem.Kind.GUN, 5.0F, 12, 3, true, true, 0);
        weapon("dragon_fury", Tf2WeaponItem.Kind.EXPLOSIVE, 15.0F, 18, 8, true, false, 1.0F);
        weapon("flare_gun", Tf2WeaponItem.Kind.GUN, 12.0F, 30, 8, true, false, 0);
        weapon("detonator", Tf2WeaponItem.Kind.EXPLOSIVE, 10.0F, 24, 10, true, false, 1.8F);
        weapon("scorch_shot", Tf2WeaponItem.Kind.EXPLOSIVE, 11.0F, 24, 9, true, false, 1.8F);
        weapon("powerjack", Tf2WeaponItem.Kind.MELEE, 9.0F, 4, 8, false, false, 0);
        weapon("backscratcher", Tf2WeaponItem.Kind.MELEE, 11.0F, 4, 10, false, false, 0);
        weapon("homewrecker", Tf2WeaponItem.Kind.MELEE, 10.0F, 4, 10, false, false, 0);
        // Demoman
        weapon("grenade_launcher", Tf2WeaponItem.Kind.EXPLOSIVE, 16.0F, 28, 10, false, false, 2.4F);
        weapon("loch_n_load", Tf2WeaponItem.Kind.EXPLOSIVE, 22.0F, 30, 10, false, false, 2.2F);
        weapon("loose_cannon", Tf2WeaponItem.Kind.EXPLOSIVE, 15.0F, 28, 9, false, false, 2.7F);
        weapon("stickybomb_launcher", Tf2WeaponItem.Kind.EXPLOSIVE, 18.0F, 25, 12, false, false, 2.8F);
        weapon("quickiebomb_launcher", Tf2WeaponItem.Kind.EXPLOSIVE, 20.0F, 25, 9, false, false, 2.8F);
        weapon("sticky_jumper", Tf2WeaponItem.Kind.EXPLOSIVE, 1.0F, 25, 9, false, false, 3.0F);
        weapon("bottle", Tf2WeaponItem.Kind.MELEE, 8.0F, 4, 9, false, false, 0);
        weapon("eyelander", Tf2WeaponItem.Kind.MELEE, 9.0F, 4, 10, false, false, 0);
        weapon("persian_persuader", Tf2WeaponItem.Kind.MELEE, 9.0F, 4, 10, false, false, 0);
        weapon("demoknight_shield", Tf2WeaponItem.Kind.SHIELD, 5.0F, 4, 12, false, true, 0);
        // Heavy
        weapon("minigun", Tf2WeaponItem.Kind.GUN, 4.0F, 28, 2, false, false, 0);
        weapon("natascha", Tf2WeaponItem.Kind.GUN, 3.0F, 26, 2, false, false, 0);
        weapon("brass_beast", Tf2WeaponItem.Kind.GUN, 5.0F, 28, 3, false, false, 0);
        weapon("tomislav", Tf2WeaponItem.Kind.GUN, 5.0F, 30, 2, false, false, 0);
        weapon("stock_shotgun", Tf2WeaponItem.Kind.GUN, 8.0F, 20, 8, false, false, 0);
        weapon("sandvich", Tf2WeaponItem.Kind.HEAL, 12.0F, 0, 0, false, false, 0);
        weapon("killing_gloves", Tf2WeaponItem.Kind.MELEE, 9.0F, 4, 8, false, false, 0);
        weapon("fists_of_steel", Tf2WeaponItem.Kind.MELEE, 10.0F, 4, 10, false, false, 0);
        // Engineer
        weapon("frontier_justice", Tf2WeaponItem.Kind.GUN, 9.0F, 22, 8, false, true, 0);
        weapon("widowmaker", Tf2WeaponItem.Kind.GUN, 8.0F, 24, 7, false, false, 0);
        weapon("pomson_6000", Tf2WeaponItem.Kind.GUN, 7.0F, 26, 7, false, false, 0);
        weapon("rescue_ranger", Tf2WeaponItem.Kind.GUN, 7.0F, 28, 8, false, false, 0);
        weapon("wrangler", Tf2WeaponItem.Kind.BUILD, 0, 1, 0, false, false, 0);
        weapon("short_circuit", Tf2WeaponItem.Kind.EXPLOSIVE, 5.0F, 12, 8, false, false, 1.0F);
        weapon("gunslinger", Tf2WeaponItem.Kind.MELEE, 8.0F, 4, 8, false, false, 0);
        weapon("jag", Tf2WeaponItem.Kind.MELEE, 7.0F, 4, 7, false, false, 0);
        weapon("southern_hospitality", Tf2WeaponItem.Kind.MELEE, 9.0F, 4, 9, true, false, 0);
        // Medic
        weapon("syringe_gun", Tf2WeaponItem.Kind.GUN, 4.0F, 22, 3, false, false, 0);
        weapon("blutsauger", Tf2WeaponItem.Kind.GUN, 5.0F, 22, 3, false, false, 0);
        weapon("crusaders_crossbow", Tf2WeaponItem.Kind.GUN, 12.0F, 35, 10, false, false, 0);
        weapon("overdose", Tf2WeaponItem.Kind.GUN, 4.0F, 24, 3, false, false, 0);
        weapon("ubersaw", Tf2WeaponItem.Kind.MELEE, 8.0F, 4, 10, false, false, 0);
        weapon("vita_saw", Tf2WeaponItem.Kind.MELEE, 7.0F, 4, 10, false, false, 0);
        weapon("amputator", Tf2WeaponItem.Kind.MELEE, 7.0F, 4, 9, false, false, 0);
        // Sniper
        weapon("sniper_rifle", Tf2WeaponItem.Kind.GUN, 30.0F, 60, 18, false, false, 0);
        weapon("machina", Tf2WeaponItem.Kind.GUN, 34.0F, 65, 20, false, false, 0);
        weapon("hitmans_heatmaker", Tf2WeaponItem.Kind.GUN, 28.0F, 60, 16, false, false, 0);
        weapon("bazaar_bargain", Tf2WeaponItem.Kind.GUN, 32.0F, 60, 18, false, false, 0);
        weapon("huntsman", Tf2WeaponItem.Kind.GUN, 22.0F, 45, 14, false, false, 0);
        weapon("fortified_compound", Tf2WeaponItem.Kind.GUN, 24.0F, 45, 15, false, false, 0);
        weapon("jarate", Tf2WeaponItem.Kind.HEAL, 3.0F, 0, 0, true, false, 0);
        weapon("smg", Tf2WeaponItem.Kind.GUN, 5.0F, 32, 3, false, false, 0);
        weapon("cleaners_carbine", Tf2WeaponItem.Kind.GUN, 6.0F, 30, 3, false, false, 0);
        weapon("tribalman_shiv", Tf2WeaponItem.Kind.MELEE, 6.0F, 4, 8, true, false, 0);
        weapon("bushwacka", Tf2WeaponItem.Kind.MELEE, 9.0F, 4, 9, false, true, 0);
        // Spy
        weapon("revolver", Tf2WeaponItem.Kind.GUN, 8.0F, 32, 7, false, false, 0);
        weapon("ambassador", Tf2WeaponItem.Kind.GUN, 12.0F, 40, 10, false, true, 0);
        weapon("letranger", Tf2WeaponItem.Kind.GUN, 6.0F, 34, 6, false, false, 0);
        weapon("enforcer", Tf2WeaponItem.Kind.GUN, 10.0F, 30, 8, false, false, 0);
        weapon("knife", Tf2WeaponItem.Kind.MELEE, 12.0F, 4, 9, true, false, 0);
        weapon("kunai", Tf2WeaponItem.Kind.MELEE, 10.0F, 4, 9, true, false, 0);
        weapon("big_earner", Tf2WeaponItem.Kind.MELEE, 11.0F, 4, 8, true, false, 0);
        weapon("spy_cicle", Tf2WeaponItem.Kind.MELEE, 10.0F, 4, 10, false, false, 0);
        weapon("your_eternal_reward", Tf2WeaponItem.Kind.MELEE, 11.0F, 4, 10, true, false, 0);
        // Classic utility
        weapon("australium_rocket_launcher", Tf2WeaponItem.Kind.EXPLOSIVE, 20.0F, 35, 10, false, true, 2.8F);
        weapon("australium_scattergun", Tf2WeaponItem.Kind.GUN, 9.0F, 26, 7, false, true, 0);
        weapon("australium_minigun", Tf2WeaponItem.Kind.GUN, 5.0F, 30, 2, false, true, 0);
    }

    private ModItems() {}
}
