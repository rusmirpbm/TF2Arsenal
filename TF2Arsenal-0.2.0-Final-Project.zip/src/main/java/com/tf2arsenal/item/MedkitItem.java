package com.tf2arsenal.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class MedkitItem extends Item {
    public MedkitItem(Properties properties) { super(properties.stacksTo(8)); }
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            player.heal(10.0F);
            player.getFoodData().eat(4, 0.4F);
            stack.shrink(1);
        }
        return InteractionResultHolder.success(stack);
    }
}
