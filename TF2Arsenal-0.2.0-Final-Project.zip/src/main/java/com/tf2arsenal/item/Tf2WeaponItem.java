package com.tf2arsenal.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

public class Tf2WeaponItem extends Item {
    public enum Kind { GUN, MELEE, EXPLOSIVE, HEAL, SHIELD, BUILD }

    private final Kind kind;
    private final float damage;
    private final double range;
    private final int cooldown;
    private final boolean bleed;
    private final boolean critBoost;
    private final float explosion;

    public Tf2WeaponItem(Properties properties, Kind kind, float damage, double range, int cooldown,
                         boolean bleed, boolean critBoost, float explosion) {
        super(properties);
        this.kind = kind;
        this.damage = damage;
        this.range = range;
        this.cooldown = cooldown;
        this.bleed = bleed;
        this.critBoost = critBoost;
        this.explosion = explosion;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            if (kind == Kind.HEAL) {
                player.heal(damage);
                stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
            } else if (kind == Kind.BUILD) {
                return InteractionResultHolder.success(stack);
            } else {
                fire(level, player);
                if (cooldown > 0) player.getCooldowns().addCooldown(this, cooldown);
                if (stack.isDamageableItem()) stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
            }
        }
        return InteractionResultHolder.success(stack);
    }

    private void fire(Level level, Player player) {
        Vec3 start = player.getEyePosition(1.0F);
        Vec3 look = player.getViewVector(1.0F).normalize();
        Vec3 end = start.add(look.scale(range));

        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class,
                new AABB(start, end).inflate(2.0), e -> e != player && e.isAlive());
        targets.sort(Comparator.comparingDouble(e -> e.distanceToSqr(player)));

        if (!targets.isEmpty()) {
            LivingEntity target = targets.get(0);
            double dist = target.distanceToSqr(start);
            if (dist <= range * range) {
                float dealt = damage;
                if (critBoost || level.random.nextFloat() < 0.025F) dealt *= 3.0F;
                target.hurt(level.damageSources().playerAttack(player), dealt);
                if (bleed) target.setRemainingFireTicks(Math.max(target.getRemainingFireTicks(), 40));
                if (explosion > 0) level.explode(player, target.getX(), target.getY(), target.getZ(), explosion, Level.ExplosionInteraction.MOB);
                return;
            }
        }

        if (explosion > 0) {
            Vec3 p = start.add(look.scale(Math.min(range, 12)));
            level.explode(player, p.x, p.y, p.z, explosion, Level.ExplosionInteraction.MOB);
            if (kind == Kind.EXPLOSIVE) {
                player.setDeltaMovement(player.getDeltaMovement().add(0, 0.75, 0).subtract(look.scale(0.28)));
                player.hurt(level.damageSources().generic(), Math.min(4.0F, explosion));
                player.hasImpulse = true;
            }
        }
    }
}
