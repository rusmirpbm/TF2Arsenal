package com.tf2arsenal.item;

import net.minecraft.world.item.Item;

public class AmmoItem extends Item {
    public AmmoItem(Properties properties) { super(properties.stacksTo(64)); }
}
