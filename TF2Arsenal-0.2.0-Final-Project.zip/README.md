# TF2 Arsenal 0.2.0 — NeoForge 1.21.1

Полный проект мода TF2 Arsenal для Minecraft 1.21.1 / NeoForge 21.1.235.

## Быстрая сборка на Windows

Требуется **64-bit Java 21** и интернет. Отдельно устанавливать Gradle не нужно.

1. Распакуйте архив.
2. Откройте терминал в корне проекта.
3. Выполните:

```bat
build.bat
```

или:

```bat
gradlew.bat build
```

При первом запуске `gradlew.bat` автоматически скачает Gradle 8.8, затем Gradle скачает NeoForge/Minecraft зависимости.

Готовый файл:

```text
build\libs\TF2Arsenal-0.2.0.jar
```

NeoForge рекомендует Java 21 для Minecraft 1.21.1 и сборку через `gradlew build`.

## Важно

Не переименовывайте ZIP в JAR. JAR создаётся именно Gradle-сборкой.

## Основное содержимое

- TF2-классы и оружие
- оружейные параметры и критические удары
- боеприпасы и Ammo Crate
- Medkit / Medi Gun
- Australium Ore / Ingots
- инженерные здания
- рецепты и локализация RU/EN
- базовые TF2-эффекты и механики
