@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set "GRADLE_VERSION=8.14"
set "DIST=%ROOT%.gradle-dist"
set "ZIP=%DIST%\gradle-%GRADLE_VERSION%-bin.zip"
set "HOME=%DIST%\gradle-%GRADLE_VERSION%"
set "GRADLE_BAT=%HOME%\bin\gradle.bat"

if exist "%GRADLE_BAT%" goto run

echo Gradle %GRADLE_VERSION% not found. Downloading it...
if not exist "%DIST%" mkdir "%DIST%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile '%ZIP%' }"
if errorlevel 1 (
  echo Failed to download Gradle. Check your internet connection.
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "& { Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%DIST%' -Force }"
if errorlevel 1 (
  echo Failed to extract Gradle.
  exit /b 1
)
del /q "%ZIP%" >nul 2>nul

:run
call "%GRADLE_BAT%" %*
exit /b %ERRORLEVEL%
